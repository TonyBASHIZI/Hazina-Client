<?php
require_once __DIR__ . '/includes/functions.php';
$pdo = getPDO();

$projects = $pdo->query(
    "SELECT p.*,
        (SELECT COUNT(DISTINCT donor_email) FROM donations WHERE project_id = p.id AND status = 'completed' AND donor_email != '') +
        (SELECT COUNT(*) FROM donations WHERE project_id = p.id AND status = 'completed' AND (donor_email = '' OR donor_email IS NULL)) AS donor_count
     FROM projects p
     WHERE p.status = 'active'
     ORDER BY p.created_at DESC"
)->fetchAll();

$pageTitle = 'Accueil';
require_once __DIR__ . '/includes/header.php';
?>

<!-- Banner -->
<div class="banner-area-two">
    <div class="banner-slider owl-theme owl-carousel">
        <div class="banner-slider-item banner-img-one">
            <div class="banner-shape">
                <img src="assets/img/banner/banner-shape1.png" alt="Shape">
            </div>
            <div class="d-table">
                <div class="d-table-cell">
                    <div class="container">
                        <div class="banner-content">
                            <span>Ensemble, changeons des vies</span>
                            <h1>Tends la main à ceux qui en ont besoin</h1>
                            <p>Chaque don compte. Découvre nos campagnes actives et soutiens une cause qui te tient à cœur.</p>
                            <div class="banner-btn-area">
                                <a class="common-btn banner-btn" href="#projects">Voir les projets</a>
                                <?php if (isClientLoggedIn()): ?>
                                    <a class="common-btn" href="#projects">Faire un don</a>
                                <?php else: ?>
                                    <a class="common-btn" href="login.php">Faire un don</a>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- End Banner -->

<!--=== Feature ===-->
<div class="feature-area two pb-70">
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-sm-6 col-lg-4">
                <div class="feature-item">
                    <i class="flaticon-solidarity"></i>
                    <h3><a href="register.php">Devenir bénévole</a></h3>
                    <p>Rejoins notre réseau de bénévoles et aide-nous à porter nos actions sur le terrain.</p>
                    <a class="feature-btn" href="register.php">Rejoindre</a>
                </div>
            </div>

            <div class="col-sm-6 col-lg-4">
                <div class="feature-item two">
                    <i class="flaticon-donation"></i>
                    <h3><a href="#projects">Faire un don</a></h3>
                    <p>Choisis une cause parmi nos projets actifs et fais un don en quelques clics.</p>
                    <a class="feature-btn" href="#projects">Donner maintenant</a>
                </div>
            </div>

            <div class="col-sm-6 col-lg-4">
                <div class="feature-item three">
                    <i class="flaticon-love"></i>
                    <h3><a href="about.php">Montre ton soutien</a></h3>
                    <p>Partage nos campagnes autour de toi pour amplifier l'impact de chaque don.</p>
                    <a class="feature-btn" href="about.php">Partager</a>
                </div>
            </div>
        </div>
    </div>
</div>
<!--=== End Feature ===-->

<!-- About -->
<div class="about-area two pb-70">
    <div class="container">
        <div class="row align-items-center">

            <div class="col-lg-6">
                <div class="about-content">
                    <div class="section-title">
                        <span class="sub-title">À propos de nous</span>
                        <h2>Nous agissons pour des causes sociales</h2>
                    </div>
                    <p>Hazina Funding met en relation des donateurs et des causes vérifiées à travers la RD Congo. Chaque contribution est suivie de manière transparente, du don jusqu'à son impact réel sur le terrain.</p>
                    <ul>
                        <li><span>01</span> Collecte de fonds depuis différentes sources</li>
                        <li><span>02</span> Aide apportée dans les zones rurales et déplacées</li>
                        <li><span>03</span> Suivi transparent de chaque don reçu</li>
                        <li><span>04</span> Intervention là où le besoin est le plus urgent</li>
                    </ul>
                    <div class="about-btn-area">
                        <a class="common-btn about-btn" href="#projects">Voir les projets</a>
                        <a class="common-btn" href="about.php">En savoir plus</a>
                    </div>
                </div>
            </div>

            <div class="col-lg-6">
                <div class="about-img">
                    <img src="assets/img/about/about-main2.jpg" alt="À propos">
                </div>
            </div>

        </div>
    </div>
</div>
<!-- End About -->

<!-- Donation -->
<section class="donations-area two pt-100 pb-70" id="projects">
    <div class="container">
        <div class="section-title">
            <span class="sub-title">Nos causes</span>
            <h2>Sois la raison du sourire de quelqu'un</h2>
            <p>Chaque projet ci-dessous est vérifié par notre équipe. Choisis une cause et fais la différence dès aujourd'hui.</p>
        </div>
        <div class="row">

            <?php foreach ($projects as $p):
                $pct = $p['goal_amount'] > 0 ? min(100, round($p['raised_amount'] / $p['goal_amount'] * 100)) : 0;
                $imgSrc = resolveImagePath($p['image']);
                $excerpt = mb_strimwidth(strip_tags($p['description']), 0, 110, '...');
            ?>
            <div class="col-sm-6 col-lg-4">
                <div class="donation-item">
                    <div class="img">
                        <img src="<?= e($imgSrc) ?>" alt="<?= e($p['title']) ?>" onerror="this.onerror=null;this.src='assets/img/donation/donation1.jpg';">
                        <a class="common-btn" href="donation-details.php?id=<?= (int)$p['id'] ?>">Faire un don</a>
                    </div>
                    <div class="inner">
                        <div class="top">
                            <?php if ($p['category']): ?>
                                <a class="tags" href="#">#<?= e($p['category']) ?></a>
                            <?php endif; ?>
                            <h3>
                                <a href="donation-details.php?id=<?= (int)$p['id'] ?>"><?= e($p['title']) ?></a>
                            </h3>
                            <p><?= e($excerpt) ?></p>
                        </div>
                        <div class="bottom">
                            <div class="skill">
                                <div class="skill-bar" style="position:relative; background:#eee; border-radius:10px; height:8px; overflow:hidden;">
                                    <div style="width:<?= $pct ?>%; background:#d62828; height:100%;"></div>
                                </div>
                                <span class="skill-count1"><?= $pct ?>%</span>
                            </div>
                            <ul>
                                <li>Collecté : <?= money((float)$p['raised_amount']) ?></li>
                                <li>Objectif : <?= money((float)$p['goal_amount']) ?></li>
                            </ul>
                            <h4>Soutenu par <span><?= (int)$p['donor_count'] ?> personne(s)</span></h4>
                        </div>
                    </div>
                </div>
            </div>
            <?php endforeach; ?>

            <?php if (!$projects): ?>
            <div class="col-12 text-center py-5">
                <p class="text-muted">Aucun projet actif pour le moment. Reviens bientôt !</p>
            </div>
            <?php endif; ?>

        </div>
    </div>
</section>
<!-- End Donation -->

<!-- Gallery -->
<section class="gallery-area two pt-100 pb-70">
    <div class="container-fluid">
        <div class="section-title">
            <span class="sub-title">Notre galerie</span>
            <h2>Découvre ce que nous faisons sur le terrain</h2>
            <p>Quelques images de nos actions et de nos campagnes récentes auprès des communautés que nous soutenons.</p>
        </div>
        <div class="gallery-slider owl-theme owl-carousel">
            <div class="gallery-item">
                <a href="assets/img/gallery/gallery1.jpg" data-lightbox="roadtrip">
                    <img src="assets/img/gallery/gallery1.jpg" alt="Galerie">
                    <i class="icofont-eye"></i>
                </a>
            </div>
            <div class="gallery-item">
                <a href="assets/img/gallery/gallery2.jpg" data-lightbox="roadtrip">
                    <img src="assets/img/gallery/gallery2.jpg" alt="Galerie">
                    <i class="icofont-eye"></i>
                </a>
            </div>
            <div class="gallery-item">
                <a href="assets/img/gallery/gallery3.jpg" data-lightbox="roadtrip">
                    <img src="assets/img/gallery/gallery3.jpg" alt="Galerie">
                    <i class="icofont-eye"></i>
                </a>
            </div>
            <div class="gallery-item">
                <a href="assets/img/gallery/gallery4.jpg" data-lightbox="roadtrip">
                    <img src="assets/img/gallery/gallery4.jpg" alt="Galerie">
                    <i class="icofont-eye"></i>
                </a>
            </div>
            <div class="gallery-item">
                <a href="assets/img/gallery/gallery5.jpg" data-lightbox="roadtrip">
                    <img src="assets/img/gallery/gallery5.jpg" alt="Galerie">
                    <i class="icofont-eye"></i>
                </a>
            </div>
            <div class="gallery-item">
                <a href="assets/img/gallery/gallery6.jpg" data-lightbox="roadtrip">
                    <img src="assets/img/gallery/gallery6.jpg" alt="Galerie">
                    <i class="icofont-eye"></i>
                </a>
            </div>
        </div>
    </div>
</section>
<!-- End Gallery -->

<!-- Dream -->
<section class="dream-area pt-100 pb-70">
    <div class="container">
        <div class="section-title">
            <span class="sub-title">Notre mission</span>
            <h2>Ensemble, changeons les choses</h2>
            <p>Chaque contribution, petite ou grande, a un impact réel sur la vie de quelqu'un.</p>
        </div>
        <div class="row">
            <div class="col-sm-6 col-lg-4">
                <div class="dream-item">
                    <h3><a href="index.php#projects">Des milliers de personnes soutenues grâce à Hazina Funding</a></h3>
                    <p>Nos campagnes touchent des familles à travers plusieurs provinces de la RD Congo.</p>
                    <h4><span>*Multi</span>provinces couvertes</h4>
                    <span class="sub-span">01</span>
                </div>
            </div>
            <div class="col-sm-6 col-lg-4">
                <div class="dream-item">
                    <h3><a href="index.php#projects">Nous soutenons les personnes déplacées avec de l'aide alimentaire</a></h3>
                    <p>Une réponse rapide et transparente aux besoins urgents sur le terrain.</p>
                    <h4><span>*Aide</span>alimentaire distribuée</h4>
                    <span class="sub-span">02</span>
                </div>
            </div>
            <div class="col-sm-6 col-lg-4">
                <div class="dream-item">
                    <h3><a href="index.php#projects">Une organisation qui lutte concrètement contre la pauvreté</a></h3>
                    <p>Chaque don est suivi et son impact est mesuré étape par étape.</p>
                    <h4><span>*Suivi</span>transparent des fonds</h4>
                    <span class="sub-span">03</span>
                </div>
            </div>
        </div>
    </div>
</section>
<!-- End Dream -->

<!-- Benefit -->
<div class="benefit-area two pt-100 pb-70">
    <div class="container">
        <div class="row align-items-center">
            <div class="col-lg-6">
                <div class="benefit-img">
                    <img src="assets/img/benefit-main1.jpg" alt="Bienfaits">
                    <img src="assets/img/benefit-shape1.png" alt="Bienfaits">
                </div>
            </div>
            <div class="col-lg-6">
                <div class="section-title">
                    <span class="sub-title">Nos domaines d'action</span>
                    <h2>Notre mission : faire sourire</h2>
                    <p>Voici les principaux domaines dans lesquels nous intervenons grâce à vos dons.</p>
                </div>
                <div class="row">
                    <div class="col-sm-6 col-sm-6">
                        <div class="benefit-item">
                            <i class="flaticon-house"></i>
                            <h3>Logement</h3>
                            <p>Aide à la reconstruction et au relogement des familles déplacées.</p>
                        </div>
                    </div>
                    <div class="col-sm-6 col-sm-6">
                        <div class="benefit-item two">
                            <i class="flaticon-hospital"></i>
                            <h3>Soins médicaux</h3>
                            <p>Accès aux soins de santé de base pour les plus vulnérables.</p>
                        </div>
                    </div>
                    <div class="col-sm-6 col-sm-6">
                        <div class="benefit-item three">
                            <i class="flaticon-fast-food"></i>
                            <h3>Nourriture & eau</h3>
                            <p>Distribution de vivres et d'eau potable dans les zones touchées.</p>
                        </div>
                    </div>
                    <div class="col-sm-6 col-sm-6">
                        <div class="benefit-item four">
                            <i class="flaticon-graduation-cap"></i>
                            <h3>Éducation</h3>
                            <p>Soutien scolaire pour les enfants des familles bénéficiaires.</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- End Benefit -->

<!--=== Team ===-->
<section class="team-area pt-100 pb-70">
    <div class="container">
        <div class="section-title">
            <span class="sub-title">Notre équipe</span>
            <h2>Rencontre nos bénévoles</h2>
            <p>Des personnes engagées, sur le terrain et derrière chaque campagne, pour que ton don ait un vrai impact.</p>
        </div>
        <div class="row justify-content-center">
            <div class="col-sm-6 col-lg-4">
                <div class="team-item">
                    <div class="top">
                        <img src="assets/img/team/team1.jpg" alt="Équipe">
                        <ul>
                            <li><a href="#" target="_blank"><i class="icofont-facebook"></i></a></li>
                            <li><a href="#" target="_blank"><i class="icofont-twitter"></i></a></li>
                            <li><a href="#" target="_blank"><i class="icofont-instagram"></i></a></li>
                        </ul>
                    </div>
                    <div class="bottom">
                        <h3>Thony B.</h3>
                        <span>Fondateur</span>
                    </div>
                </div>
            </div>
            <div class="col-sm-6 col-lg-4">
                <div class="team-item">
                    <div class="top">
                        <img src="assets/img/team/team2.jpg" alt="Équipe">
                        <ul>
                            <li><a href="#" target="_blank"><i class="icofont-facebook"></i></a></li>
                            <li><a href="#" target="_blank"><i class="icofont-twitter"></i></a></li>
                            <li><a href="#" target="_blank"><i class="icofont-instagram"></i></a></li>
                        </ul>
                    </div>
                    <div class="bottom">
                        <h3>Membre équipe</h3>
                        <span>Coordinateur terrain</span>
                    </div>
                </div>
            </div>
            <div class="col-sm-6 col-lg-4">
                <div class="team-item">
                    <div class="top">
                        <img src="assets/img/team/team3.jpg" alt="Équipe">
                        <ul>
                            <li><a href="#" target="_blank"><i class="icofont-facebook"></i></a></li>
                            <li><a href="#" target="_blank"><i class="icofont-twitter"></i></a></li>
                            <li><a href="#" target="_blank"><i class="icofont-instagram"></i></a></li>
                        </ul>
                    </div>
                    <div class="bottom">
                        <h3>Bénévole</h3>
                        <span>Volontaire</span>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<!--=== End Team ===-->

<?php require_once __DIR__ . '/includes/footer.php'; ?>
